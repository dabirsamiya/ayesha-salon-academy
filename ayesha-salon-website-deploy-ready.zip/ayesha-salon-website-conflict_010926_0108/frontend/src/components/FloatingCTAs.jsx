import { useLocation, useNavigate } from "react-router-dom";
import { Phone, MessageCircle, User } from "lucide-react";
import { CONTACT, WHATSAPP } from "../lib/data";
import { useAuth } from "../context/AuthContext";

export default function FloatingCTAs() {
  const loc = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isFitness = loc.pathname === "/fitness";

  const phone = isFitness ? CONTACT.fitnessPhoneRaw : CONTACT.salonPhoneRaw;
  const waLink = isFitness ? WHATSAPP.fitness() : WHATSAPP.salonGeneral();

  // hide on dashboard/admin/login
  if (["/login", "/dashboard", "/admin", "/payment-result"].includes(loc.pathname)) return null;

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-3">
      <a
        href={waLink}
        target="_blank"
        rel="noreferrer"
        data-testid="float-whatsapp"
        className="h-13 w-13 p-3.5 grid place-items-center rounded-full bg-[#25D366] text-white shadow-lg hover:scale-110 transition-transform"
        aria-label="WhatsApp"
      >
        <MessageCircle size={22} />
      </a>
      <a
        href={`tel:${phone}`}
        data-testid="float-call"
        className="h-13 w-13 p-3.5 grid place-items-center rounded-full bg-gold text-white shadow-lg hover:scale-110 transition-transform"
        aria-label="Call"
      >
        <Phone size={20} />
      </a>
      <button
        onClick={() => navigate(user && user !== false ? (user.role === "admin" ? "/admin" : "/dashboard") : "/login")}
        data-testid="float-login"
        className="h-13 w-13 p-3.5 grid place-items-center rounded-full bg-ink text-white shadow-lg hover:scale-110 transition-transform"
        aria-label="Student Login"
      >
        <User size={20} />
      </button>
    </div>
  );
}
