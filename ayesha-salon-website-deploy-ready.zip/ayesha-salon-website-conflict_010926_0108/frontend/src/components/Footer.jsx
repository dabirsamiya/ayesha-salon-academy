import { Link } from "react-router-dom";
import { Instagram, Facebook, Youtube, Phone, Mail, MapPin, Clock } from "lucide-react";
import { BRAND, CONTACT, SOCIAL, WHATSAPP, HOURS } from "../lib/data";

export default function Footer() {
  return (
    <footer data-testid="footer" className="bg-ink text-white/80">
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-16 grid md:grid-cols-4 gap-12">
        <div className="md:col-span-1">
          <div className="flex items-center gap-3 mb-5">
            <img src={BRAND.logo} alt="logo" className="h-12 w-12 rounded-full object-cover ring-1 ring-gold/50" />
            <span className="font-serif text-lg text-white">Ayesha Salon<br /><span className="text-gold text-sm">& Academy</span></span>
          </div>
          <p className="text-sm leading-relaxed text-white/60">{BRAND.tagline}</p>
        </div>

        <div>
          <h4 className="text-white font-serif text-lg mb-4">Explore</h4>
          <ul className="space-y-2.5 text-sm">
            <li><Link to="/" className="hover:text-gold transition-colors">Home</Link></li>
            <li><Link to="/services" className="hover:text-gold transition-colors">Services & Gallery</Link></li>
            <li><Link to="/academy" className="hover:text-gold transition-colors">Academy</Link></li>
            <li><Link to="/fitness" className="hover:text-gold transition-colors">Fitness Coaching</Link></li>
            <li><Link to="/reviews" className="hover:text-gold transition-colors">Reviews & Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-serif text-lg mb-4">Get in Touch</h4>
          <ul className="space-y-3 text-sm">
            <li><a href={`tel:${CONTACT.salonPhoneRaw}`} className="flex items-center gap-2.5 hover:text-gold"><Phone size={15} strokeWidth={1.5} /> {CONTACT.salonPhone}</a></li>
            <li><a href={`mailto:${CONTACT.email}`} className="flex items-center gap-2.5 hover:text-gold"><Mail size={15} strokeWidth={1.5} /> {CONTACT.email}</a></li>
            <li className="flex items-start gap-2.5"><MapPin size={16} strokeWidth={1.5} className="mt-0.5 shrink-0" /> <span className="text-white/60">{CONTACT.address}</span></li>
            <li className="flex items-start gap-2.5"><Clock size={15} strokeWidth={1.5} className="mt-0.5 shrink-0" /> <span className="text-white/60">{HOURS}</span></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-serif text-lg mb-4">Follow Us</h4>
          <div className="flex gap-3">
            <a href={SOCIAL.salon.instagram} target="_blank" rel="noreferrer" data-testid="footer-instagram" className="h-10 w-10 grid place-items-center rounded-full border border-white/15 hover:border-gold hover:text-gold transition-colors"><Instagram size={17} strokeWidth={1.5} /></a>
            <a href={SOCIAL.salon.facebook} target="_blank" rel="noreferrer" data-testid="footer-facebook" className="h-10 w-10 grid place-items-center rounded-full border border-white/15 hover:border-gold hover:text-gold transition-colors"><Facebook size={17} strokeWidth={1.5} /></a>
            <a href={SOCIAL.salon.youtube} target="_blank" rel="noreferrer" data-testid="footer-youtube" className="h-10 w-10 grid place-items-center rounded-full border border-white/15 hover:border-gold hover:text-gold transition-colors"><Youtube size={17} strokeWidth={1.5} /></a>
          </div>
          <a href={WHATSAPP.salonGeneral()} target="_blank" rel="noreferrer" className="inline-block mt-5 text-sm text-gold hover:underline">Chat on WhatsApp →</a>
        </div>
      </div>
      <div className="border-t border-white/10 py-6 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Ayesha Salon & Academy. All rights reserved.
      </div>
    </footer>
  );
}
