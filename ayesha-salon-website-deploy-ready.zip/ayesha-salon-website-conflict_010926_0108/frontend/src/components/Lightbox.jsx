import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect } from "react";

export default function Lightbox({ images, index, onClose, setIndex }) {
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setIndex((i) => (i + 1) % images.length);
      if (e.key === "ArrowLeft") setIndex((i) => (i - 1 + images.length) % images.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [images.length, onClose, setIndex]);

  if (index == null) return null;
  return (
    <div data-testid="lightbox" className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-sm grid place-items-center p-4" onClick={onClose}>
      <button data-testid="lightbox-close" className="absolute top-5 right-5 text-white/80 hover:text-white" onClick={onClose}><X size={30} /></button>
      <button className="absolute left-4 md:left-10 text-white/70 hover:text-white" onClick={(e) => { e.stopPropagation(); setIndex((index - 1 + images.length) % images.length); }}><ChevronLeft size={40} /></button>
      <img src={images[index]} alt="gallery" className="max-h-[85vh] max-w-[90vw] object-contain rounded-lg" onClick={(e) => e.stopPropagation()} />
      <button className="absolute right-4 md:right-10 text-white/70 hover:text-white" onClick={(e) => { e.stopPropagation(); setIndex((index + 1) % images.length); }}><ChevronRight size={40} /></button>
    </div>
  );
}
