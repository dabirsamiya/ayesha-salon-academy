import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, Phone, User } from "lucide-react";
import { BRAND, CONTACT } from "../lib/data";
import { useAuth } from "../context/AuthContext";

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services & Gallery" },
  { to: "/academy", label: "Academy" },
  { to: "/fitness", label: "Fitness Coaching" },
  { to: "/reviews", label: "Reviews & Contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const loc = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => setOpen(false), [loc.pathname]);

  const dark = loc.pathname === "/" && !scrolled;

  return (
    <header
      data-testid="navbar"
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-white/80 backdrop-blur-2xl border-b border-line shadow-[0_1px_20px_rgba(0,0,0,0.03)]" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 md:px-8 flex items-center justify-between h-20">
        <Link to="/" data-testid="nav-logo" className="flex items-center gap-3">
          <img src={BRAND.logo} alt="Ayesha Salon & Academy" className="h-11 w-11 rounded-full object-cover ring-1 ring-gold/40" />
          <span className={`font-serif text-lg leading-tight ${dark ? "text-white" : "text-ink"}`}>
            Ayesha<span className="text-gold"> Salon & Academy</span>
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-9">
          {LINKS.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              data-testid={`nav-${l.label.split(" ")[0].toLowerCase()}`}
              className={`text-[13px] font-medium tracking-wide relative group ${
                dark ? "text-white/90" : loc.pathname === l.to ? "text-gold" : "text-ink-soft hover:text-ink"
              } transition-colors`}
            >
              {l.label}
              <span className="absolute -bottom-1.5 left-0 h-px bg-gold transition-all duration-300 w-0 group-hover:w-full" />
            </Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-3">
          <a href={`tel:${CONTACT.salonPhoneRaw}`} data-testid="nav-call" className={`flex items-center gap-2 text-[13px] font-medium ${dark ? "text-white" : "text-ink"}`}>
            <Phone size={15} strokeWidth={1.6} /> Call
          </a>
          <button
            data-testid="nav-student-login"
            onClick={() => navigate(user && user !== false ? (user.role === "admin" ? "/admin" : "/dashboard") : "/login")}
            className="flex items-center gap-2 rounded-full bg-ink text-white px-5 py-2.5 text-[13px] font-medium hover:bg-gold transition-colors duration-300"
          >
            <User size={15} strokeWidth={1.6} /> {user && user !== false ? "My Account" : "Student Login"}
          </button>
        </div>

        <button data-testid="nav-mobile-toggle" onClick={() => setOpen(!open)} className={`lg:hidden ${dark ? "text-white" : "text-ink"}`}>
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-white border-t border-line px-5 py-6 space-y-1" data-testid="mobile-menu">
          {LINKS.map((l) => (
            <Link key={l.to} to={l.to} className="block py-3 text-ink font-medium border-b border-line/60">
              {l.label}
            </Link>
          ))}
          <div className="flex gap-3 pt-4">
            <a href={`tel:${CONTACT.salonPhoneRaw}`} className="flex-1 text-center rounded-full border border-ink py-3 text-sm font-medium">Call</a>
            <button
              onClick={() => navigate(user && user !== false ? (user.role === "admin" ? "/admin" : "/dashboard") : "/login")}
              className="flex-1 rounded-full bg-ink text-white py-3 text-sm font-medium"
            >
              {user && user !== false ? "My Account" : "Student Login"}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
