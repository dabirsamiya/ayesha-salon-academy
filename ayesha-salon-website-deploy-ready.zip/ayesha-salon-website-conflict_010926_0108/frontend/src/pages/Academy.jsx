import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Clock, CheckCircle2, GraduationCap, Award, Users, Video, Radio, MessageCircle } from "lucide-react";
import api, { formatApiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { MEET, WHATSAPP } from "../lib/data";
import Reveal from "../components/Reveal";
import { toast } from "sonner";

const money = (n) => `₹${Number(n).toLocaleString("en-IN")}`;

export default function Academy() {
  const [courses, setCourses] = useState([]);
  const [busy, setBusy] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/courses?type=academy").then((r) => setCourses(r.data)).catch(() => {});
  }, []);

  const join = async (item_id) => {
    if (!user || user === false) { navigate(`/login?redirect=/academy`); return; }
    setBusy(item_id);
    try {
      const { data } = await api.post("/payments/create", { item_type: "course", item_id });
      navigate(`/payment-result?order=${data.merchant_order_id}`);
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail));
    } finally { setBusy(null); }
  };

  return (
    <div data-testid="academy-page" className="pt-20">
      <section className="py-20 md:py-28 bg-surface text-center px-5">
        <Reveal>
          <p className="overline mb-4">Academy & Masterclasses</p>
          <h1 className="font-serif font-light text-4xl md:text-6xl text-ink max-w-3xl mx-auto leading-tight">Professional beauty education</h1>
          <p className="text-ink-soft max-w-xl mx-auto mt-6">Industry-focused courses to build confidence, develop skills and launch your career in beauty.</p>
          <a href={MEET.salon} target="_blank" rel="noreferrer" data-testid="academy-live-masterclass-btn" className="inline-flex items-center gap-2 rounded-full bg-red-600 text-white px-7 py-3.5 text-sm font-medium hover:bg-red-700 transition-colors mt-8 shadow-lg">
            <Radio size={16} /> Join Live Masterclass
          </a>
        </Reveal>
      </section>

      {/* COURSES — exactly four */}
      <section className="py-20 md:py-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Reveal><div className="mb-12"><p className="overline mb-3">Courses</p><h2 className="font-serif font-light text-3xl md:text-5xl text-ink">Our four signature courses</h2></div></Reveal>
          <div className="grid md:grid-cols-2 gap-8">
            {courses.map((c, i) => (
              <Reveal key={c.id} delay={i * 90}>
                <div data-testid="course-card" className="flex flex-col rounded-2xl overflow-hidden border border-line bg-white hover:shadow-xl transition-shadow duration-500 h-full">
                  <div className="bg-cream flex items-center justify-center p-3">
                    <img src={c.image} alt={c.name} className="w-full max-h-[420px] object-contain rounded-lg" />
                  </div>
                  <div className="p-7 flex flex-col flex-1">
                    <h3 className="font-serif text-2xl text-ink mb-3">{c.name}</h3>
                    <p className="text-sm text-ink-soft leading-relaxed mb-5">{c.description}</p>
                    <div className="flex flex-wrap gap-3 mb-5">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-cream px-3.5 py-1.5 text-xs font-medium text-ink"><Clock size={13} className="text-gold" /> {c.duration_label || `${c.duration_days} Days`}</span>
                      {c.certificate_text && <span className="inline-flex items-center gap-1.5 rounded-full bg-cream px-3.5 py-1.5 text-xs font-medium text-ink"><Award size={13} className="text-gold" /> {c.certificate_text}</span>}
                    </div>
                    <ul className="space-y-2 mb-6">
                      {(c.features || []).map((f) => (
                        <li key={f} className="flex items-center gap-2 text-sm text-ink-soft"><CheckCircle2 size={15} className="text-gold shrink-0" strokeWidth={1.6} /> {f}</li>
                      ))}
                    </ul>
                    <div className="mt-auto pt-4 border-t border-line">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-serif text-3xl text-ink">{money(c.price)}</span>
                        <button data-testid="course-join-btn" disabled={busy === c.id} onClick={() => join(c.id)} className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-7 py-3.5 text-sm font-medium hover:bg-gold transition-colors disabled:opacity-60">
                          {busy === c.id ? "Processing…" : "Join Now"} <ArrowRight size={15} />
                        </button>
                      </div>
                      <a href={WHATSAPP.courseEnquire(c.name)} target="_blank" rel="noreferrer" data-testid="course-enquire-btn" className="flex items-center justify-center gap-2 rounded-full border border-gold text-ink px-5 py-3 text-sm font-medium hover:bg-gold hover:text-white transition-colors">
                        Enquire on WhatsApp <MessageCircle size={15} />
                      </a>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* enrollment flow */}
      <section className="py-16 bg-cream">
        <div className="max-w-5xl mx-auto px-5 md:px-8 grid sm:grid-cols-4 gap-6 text-center">
          {[
            { icon: Users, t: "Register / Login", d: "Create your student account" },
            { icon: GraduationCap, t: "Select Course", d: "Choose your program" },
            { icon: CheckCircle2, t: "Secure Payment", d: "Pay via PhonePe" },
            { icon: Video, t: "Get Access", d: "Recorded lectures & live class" },
          ].map((s, i) => (
            <Reveal key={s.t} delay={i * 80}>
              <s.icon className="mx-auto text-gold mb-3" size={30} strokeWidth={1.3} />
              <p className="font-medium text-ink">{s.t}</p>
              <p className="text-xs text-ink-soft mt-1">{s.d}</p>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
