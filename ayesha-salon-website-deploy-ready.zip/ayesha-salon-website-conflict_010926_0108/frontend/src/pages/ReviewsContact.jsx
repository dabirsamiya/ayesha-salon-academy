import { useEffect, useState } from "react";
import { Star, MapPin, Phone, Mail, Instagram, Facebook, Youtube, ArrowRight, QrCode, Clock } from "lucide-react";
import api from "../lib/api";
import { CONTACT, SOCIAL, WHATSAPP, MEDIA, TESTIMONIAL_VIDEOS, BRAND, HOURS, videoPoster } from "../lib/data";
import Reveal from "../components/Reveal";

export default function ReviewsContact() {
  const [config, setConfig] = useState({});
  useEffect(() => { api.get("/config").then((r) => setConfig(r.data)).catch(() => {}); }, []);

  return (
    <div data-testid="reviews-page" className="pt-20">
      <section className="py-20 md:py-28 bg-surface text-center px-5">
        <Reveal>
          <p className="overline mb-4">Reviews & Contact</p>
          <h1 className="font-serif font-light text-4xl md:text-6xl text-ink max-w-3xl mx-auto leading-tight">Loved by our clients</h1>
          <p className="text-ink-soft max-w-xl mx-auto mt-6">Hear directly from the people we've had the pleasure of serving.</p>
        </Reveal>
      </section>

      {/* video testimonials */}
      <section className="py-20 md:py-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Reveal><div className="mb-12"><p className="overline mb-3">Testimonials</p><h2 className="font-serif font-light text-3xl md:text-5xl text-ink">Client stories</h2></div></Reveal>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {TESTIMONIAL_VIDEOS.map((v, i) => (
              <Reveal key={v} delay={(i % 5) * 60}>
                <div data-testid="testimonial-video">
                  <div className="rounded-xl overflow-hidden border border-line bg-black aspect-[9/16]">
                    <video className="h-full w-full object-cover" src={v} poster={videoPoster(v, 1)} controls playsInline preload="metadata" />
                  </div>
                  <p className="text-center text-xs font-semibold tracking-wide text-gold mt-2">★★★★★ CLIENT REVIEW</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* QR codes */}
      <section className="py-20 md:py-24 bg-cream">
        <div className="max-w-5xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-8">
          <Reveal>
            <div className="bg-white rounded-2xl border border-line p-8 text-center h-full">
              <Star className="mx-auto text-gold mb-4" size={30} strokeWidth={1.3} fill="#C5A880" />
              <h3 className="font-serif text-2xl text-ink mb-2">Check Us Out on Google</h3>
              <p className="text-sm text-ink-soft mb-6">Scan the QR code and share your experience with us on Google.</p>
              {config.google_review_link ? (
                <a href={config.google_review_link} target="_blank" rel="noreferrer" data-testid="review-qr-link">
                  <img src={MEDIA.googleReviewQR} alt="Google Review QR" className="mx-auto w-48 h-48 object-contain rounded-lg hover:scale-105 transition-transform" />
                </a>
              ) : (
                <img src={MEDIA.googleReviewQR} alt="Google Review QR" className="mx-auto w-48 h-48 object-contain rounded-lg" />
              )}
              {config.google_review_link && (
                <a href={config.google_review_link} target="_blank" rel="noreferrer" data-testid="leave-review-btn" className="inline-flex items-center gap-2 rounded-full bg-gold text-white px-6 py-3 text-sm font-medium hover:bg-gold-hover transition-colors mt-6">
                  ⭐ Check Our Reviews on Google <ArrowRight size={15} />
                </a>
              )}
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="bg-white rounded-2xl border border-line p-8 text-center h-full">
              <QrCode className="mx-auto text-gold mb-4" size={30} strokeWidth={1.3} />
              <h3 className="font-serif text-2xl text-ink mb-2">Find Us on Google</h3>
              <p className="text-sm text-ink-soft mb-6">Scan the code to find Ayesha Salon & Academy on Google.</p>
              <img src={MEDIA.findUsQR} alt="Find Us QR" className="mx-auto w-48 h-48 object-contain rounded-lg" />
              {config.google_maps_link && (
                <a href={config.google_maps_link} target="_blank" rel="noreferrer" data-testid="get-directions-btn" className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-6 py-3 text-sm font-medium hover:bg-gold transition-colors mt-6">
                  Get Directions <ArrowRight size={15} />
                </a>
              )}
            </div>
          </Reveal>
        </div>
      </section>

      {/* contact */}
      <section className="py-20 md:py-28">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-14">
          <Reveal>
            <p className="overline mb-4">Contact</p>
            <h2 className="font-serif font-light text-3xl md:text-5xl text-ink mb-8">{BRAND.name}</h2>
            <ul className="space-y-6">
              <li className="flex items-start gap-4">
                <Phone className="text-gold mt-1 shrink-0" size={20} strokeWidth={1.5} />
                <div>
                  <p className="text-xs text-ink-soft uppercase tracking-wider mb-1">Phone</p>
                  <a href={`tel:${CONTACT.salonPhoneRaw}`} data-testid="contact-call" className="text-ink font-medium hover:text-gold">{CONTACT.salonPhone}</a>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <Mail className="text-gold mt-1 shrink-0" size={20} strokeWidth={1.5} />
                <div>
                  <p className="text-xs text-ink-soft uppercase tracking-wider mb-1">Email</p>
                  <a href={`mailto:${CONTACT.email}`} data-testid="contact-email" className="text-ink font-medium hover:text-gold break-all">{CONTACT.email}</a>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <MapPin className="text-gold mt-1 shrink-0" size={20} strokeWidth={1.5} />
                <div>
                  <p className="text-xs text-ink-soft uppercase tracking-wider mb-1">Address</p>
                  <p className="text-ink font-medium leading-relaxed">{CONTACT.address}</p>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <Clock className="text-gold mt-1 shrink-0" size={20} strokeWidth={1.5} />
                <div>
                  <p className="text-xs text-ink-soft uppercase tracking-wider mb-1">Opening Hours</p>
                  <p className="text-ink font-medium leading-relaxed" data-testid="opening-hours">{HOURS}</p>
                </div>
              </li>
            </ul>
            <div className="flex gap-3 mt-8">
              <a href={SOCIAL.salon.instagram} target="_blank" rel="noreferrer" data-testid="contact-instagram" className="h-11 w-11 grid place-items-center rounded-full border border-line hover:border-gold hover:text-gold transition-colors"><Instagram size={18} strokeWidth={1.5} /></a>
              <a href={SOCIAL.salon.facebook} target="_blank" rel="noreferrer" data-testid="contact-facebook" className="h-11 w-11 grid place-items-center rounded-full border border-line hover:border-gold hover:text-gold transition-colors"><Facebook size={18} strokeWidth={1.5} /></a>
              <a href={SOCIAL.salon.youtube} target="_blank" rel="noreferrer" data-testid="contact-youtube" className="h-11 w-11 grid place-items-center rounded-full border border-line hover:border-gold hover:text-gold transition-colors"><Youtube size={18} strokeWidth={1.5} /></a>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <div className="bg-ink text-white rounded-2xl p-10 h-full flex flex-col justify-center">
              <h3 className="font-serif text-3xl mb-4">Ready to visit?</h3>
              <p className="text-white/70 mb-8 leading-relaxed">Book an appointment or ask us anything on WhatsApp — we'd love to hear from you.</p>
              <a href={WHATSAPP.salonGeneral()} target="_blank" rel="noreferrer" data-testid="contact-whatsapp" className="inline-flex items-center justify-center gap-2 rounded-full bg-gold text-white px-8 py-4 text-sm font-medium hover:bg-gold-hover transition-colors mb-4">
                Chat on WhatsApp <ArrowRight size={16} />
              </a>
              <a href={`tel:${CONTACT.salonPhoneRaw}`} className="inline-flex items-center justify-center gap-2 rounded-full border border-white/40 text-white px-8 py-4 text-sm font-medium hover:bg-white hover:text-ink transition-colors">
                <Phone size={16} /> Call Now
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
