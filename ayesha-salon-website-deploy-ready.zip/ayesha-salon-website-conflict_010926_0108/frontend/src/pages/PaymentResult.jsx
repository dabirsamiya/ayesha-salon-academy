import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import api from "../lib/api";

export default function PaymentResult() {
  const [params] = useSearchParams();
  const order = params.get("order");
  const [status, setStatus] = useState("processing");
  const navigate = useNavigate();

  useEffect(() => {
    if (!order) { setStatus("failed"); return; }
    (async () => {
      try {
        // Mock mode: complete the payment server-side, then verify.
        await api.post(`/payments/${order}/mock-complete`).catch(() => {});
        const { data } = await api.get(`/payments/${order}`);
        setStatus(data.access ? "success" : "failed");
      } catch {
        setStatus("failed");
      }
    })();
  }, [order]);

  return (
    <div className="min-h-screen grid place-items-center bg-surface px-5" data-testid="payment-result-page">
      <div className="bg-white rounded-2xl border border-line p-12 text-center max-w-md w-full">
        {status === "processing" && (<><Loader2 className="mx-auto text-gold mb-5 animate-spin" size={48} /><h1 className="font-serif text-2xl text-ink mb-2">Processing payment…</h1><p className="text-ink-soft text-sm">Please wait while we confirm your enrolment.</p></>)}
        {status === "success" && (<><CheckCircle2 className="mx-auto text-green-600 mb-5" size={54} strokeWidth={1.4} /><h1 className="font-serif text-3xl text-ink mb-2">Payment Successful!</h1><p className="text-ink-soft text-sm mb-8">Your course access is now active for 30 days.</p><button data-testid="go-dashboard-btn" onClick={() => navigate("/dashboard")} className="rounded-full bg-ink text-white px-8 py-3.5 text-sm font-medium hover:bg-gold transition-colors">Go to Dashboard</button></>)}
        {status === "failed" && (<><XCircle className="mx-auto text-red-500 mb-5" size={54} strokeWidth={1.4} /><h1 className="font-serif text-2xl text-ink mb-2">Payment Failed</h1><p className="text-ink-soft text-sm mb-8">We couldn't confirm your payment. Please try again.</p><button onClick={() => navigate("/academy")} className="rounded-full bg-ink text-white px-8 py-3.5 text-sm font-medium hover:bg-gold transition-colors">Back to Academy</button></>)}
      </div>
    </div>
  );
}
