import { useState } from "react";
import { ArrowRight, Crown } from "lucide-react";
import { SERVICES, GALLERY, WHATSAPP, bridalMessage } from "../lib/data";
import Reveal from "../components/Reveal";
import Lightbox from "../components/Lightbox";

const field = "w-full rounded-lg border border-line bg-white px-4 py-3 text-sm text-black placeholder:text-gray-500 caret-black outline-none focus:border-gold focus:ring-1 focus:ring-gold";

function BridalForm() {
  const [f, setF] = useState({ name: "", phone: "", weddingDate: "", trialDate: "", services: "", budget: "", location: "", people: "", notes: "" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    window.open(bridalMessage(f), "_blank");
  };
  return (
    <form onSubmit={submit} data-testid="bridal-form" className="grid sm:grid-cols-2 gap-4">
      <input data-testid="bridal-name" required value={f.name} onChange={set("name")} placeholder="Full Name" className={field} />
      <input data-testid="bridal-phone" required value={f.phone} onChange={set("phone")} placeholder="Phone Number" className={field} />
      <div><label className="text-xs text-white/60 mb-1 block">Wedding Date</label><input data-testid="bridal-wedding" type="date" value={f.weddingDate} onChange={set("weddingDate")} className={field} /></div>
      <div><label className="text-xs text-white/60 mb-1 block">Preferred Trial Date</label><input data-testid="bridal-trial" type="date" value={f.trialDate} onChange={set("trialDate")} className={field} /></div>
      <input data-testid="bridal-services" value={f.services} onChange={set("services")} placeholder="Services Required" className={field} />
      <input data-testid="bridal-budget" value={f.budget} onChange={set("budget")} placeholder="Budget" className={field} />
      <input data-testid="bridal-location" value={f.location} onChange={set("location")} placeholder="Location" className={field} />
      <input data-testid="bridal-people" value={f.people} onChange={set("people")} placeholder="No. of People Needing Makeup" className={field} />
      <textarea data-testid="bridal-notes" value={f.notes} onChange={set("notes")} placeholder="Additional Notes" rows="2" className={`${field} sm:col-span-2`} />
      <button data-testid="bridal-submit" type="submit" className="sm:col-span-2 inline-flex items-center justify-center gap-2 rounded-full bg-gold text-white px-8 py-4 text-sm font-medium hover:bg-gold-hover transition-colors">
        Send Bridal Trial Inquiry <ArrowRight size={16} />
      </button>
    </form>
  );
}

export default function ServicesGallery() {
  const [lb, setLb] = useState(null);

  return (
    <div data-testid="services-page" className="pt-20">
      <section className="py-20 md:py-28 bg-surface text-center px-5">
        <Reveal>
          <p className="overline mb-4">Services & Gallery</p>
          <h1 className="font-serif font-light text-4xl md:text-6xl text-ink max-w-3xl mx-auto leading-tight">Salon services crafted with care</h1>
          <p className="text-ink-soft max-w-xl mx-auto mt-6">Explore our full range of beauty and grooming services. Enquire directly on WhatsApp for details and timings.</p>
        </Reveal>
      </section>

      {/* services */}
      <section className="py-20 md:py-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8 space-y-14">
          {SERVICES.map((cat, ci) => (
            <Reveal key={cat.category} delay={ci * 40}>
              <div>
                <div className="flex items-center gap-4 mb-6">
                  <h2 className="font-serif text-2xl md:text-3xl text-ink">{cat.category}</h2>
                  <div className="flex-1 h-px bg-line" />
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {cat.items.map((name) => (
                    <div key={name} data-testid="service-card" className="group flex items-center justify-between gap-4 rounded-xl border border-line bg-white px-5 py-4 hover:border-gold hover:shadow-md transition-all">
                      <span className="text-ink font-medium text-sm">{name}</span>
                      <a href={WHATSAPP.salonService(name)} target="_blank" rel="noreferrer" data-testid="service-enquire-btn" className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-cream text-ink px-4 py-2 text-xs font-medium group-hover:bg-gold group-hover:text-white transition-colors">
                        Enquire Now <ArrowRight size={13} />
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* bridal trial */}
      <section className="py-20 md:py-28 bg-ink text-white">
        <div className="max-w-5xl mx-auto px-5 md:px-8">
          <Reveal>
            <div className="text-center mb-10">
              <Crown className="text-gold mx-auto mb-4" size={34} strokeWidth={1.3} />
              <p className="overline mb-3">Bridal Studio</p>
              <h2 className="font-serif font-light text-3xl md:text-5xl leading-tight mb-4">Book Your Bridal Trial</h2>
              <p className="text-white/70 max-w-xl mx-auto">Fill in your details and we'll continue on WhatsApp to craft your perfect bridal look.</p>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
              <BridalForm />
            </div>
          </Reveal>
        </div>
      </section>

      {/* gallery */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Reveal>
            <div className="text-center mb-12">
              <p className="overline mb-4">Full Gallery</p>
              <h2 className="font-serif font-light text-3xl md:text-5xl text-ink">Our Gallery</h2>
            </div>
          </Reveal>
          <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
            {GALLERY.map((img, i) => (
              <Reveal key={img} delay={(i % 4) * 60}>
                <button data-testid="gallery-image" onClick={() => setLb(i)} className="block w-full overflow-hidden rounded-xl break-inside-avoid">
                  <img src={img} alt="gallery" loading="lazy" className="w-full object-cover hover:scale-105 transition-transform duration-700" />
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <Lightbox images={GALLERY} index={lb} setIndex={setLb} onClose={() => setLb(null)} />
    </div>
  );
}
