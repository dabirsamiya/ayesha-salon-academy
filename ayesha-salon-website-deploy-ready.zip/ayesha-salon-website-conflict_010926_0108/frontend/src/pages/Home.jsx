import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Play, Sparkles, Scissors, GraduationCap } from "lucide-react";
import api from "../lib/api";
import { BRAND, WHATSAPP, MEDIA, GALLERY, FEATURED_SERVICES, TESTIMONIAL_VIDEOS, LANDING_VIDEO, MEET, videoPoster } from "../lib/data";
import Reveal from "../components/Reveal";

export default function Home() {
  const [config, setConfig] = useState({});
  useEffect(() => { api.get("/config").then((r) => setConfig(r.data)).catch(() => {}); }, []);

  return (
    <div data-testid="home-page">
      {/* HERO */}
      <section className="relative h-screen min-h-[640px] w-full overflow-hidden">
        <video data-testid="hero-video" className="absolute inset-0 h-full w-full object-cover" src={config.hero_video_url || LANDING_VIDEO} autoPlay muted loop playsInline preload="auto" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/70" />
        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-5">
          <Reveal>
            <img src={BRAND.logo} alt="logo" className="h-24 w-24 rounded-full object-cover ring-2 ring-gold/60 mx-auto mb-7 shadow-2xl" />
          </Reveal>
          <Reveal delay={120}>
            <p className="overline text-gold mb-4">Beauty · Academy · Aesthetics</p>
          </Reveal>
          <Reveal delay={200}>
            <h1 className="font-serif font-light text-white text-4xl sm:text-5xl lg:text-7xl max-w-4xl leading-[1.05]">
              Where Beauty Meets <span className="italic text-gold">Mastery</span>
            </h1>
          </Reveal>
          <Reveal delay={320}>
            <p className="text-white/80 max-w-xl mx-auto mt-6 text-base leading-relaxed">
              Premium salon services and industry-focused beauty education. Learn, create, and grow with Ayesha Salon & Academy.
            </p>
          </Reveal>
          <Reveal delay={440}>
            <div className="flex flex-wrap gap-4 justify-center mt-9">
              <a href={WHATSAPP.salonAppointment()} target="_blank" rel="noreferrer" data-testid="hero-book-btn" className="inline-flex items-center gap-2 rounded-full bg-gold text-white px-8 py-4 text-sm font-medium hover:bg-gold-hover transition-colors duration-300">
                Book an Appointment <ArrowRight size={16} />
              </a>
              <Link to="/academy" data-testid="hero-academy-btn" className="inline-flex items-center gap-2 rounded-full border border-white/60 text-white px-8 py-4 text-sm font-medium hover:bg-white hover:text-ink transition-colors duration-300">
                Explore Academy
              </Link>
              <a href={MEET.salon} target="_blank" rel="noreferrer" data-testid="hero-live-masterclass-btn" className="inline-flex items-center gap-2 rounded-full bg-red-600 text-white px-8 py-4 text-sm font-medium hover:bg-red-700 transition-colors duration-300 shadow-lg">
                <span className="h-2.5 w-2.5 rounded-full bg-white animate-pulse" /> Join Live Masterclass
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ABOUT */}
      <section className="py-24 md:py-32 bg-surface">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-16 items-center">
          <Reveal>
            <div className="relative">
              <img src={GALLERY[1]} alt="salon" className="rounded-2xl w-full h-[520px] object-cover" />
              <div className="absolute -bottom-8 -right-4 md:-right-8 bg-white rounded-2xl p-7 shadow-xl border border-line max-w-[240px]">
                <Sparkles className="text-gold mb-2" strokeWidth={1.4} />
                <p className="font-serif text-2xl text-ink">Learn.<br />Create.<br />Grow.</p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <p className="overline mb-4">About Us</p>
            <h2 className="font-serif font-light text-3xl md:text-5xl text-ink leading-tight mb-7">
              Enhancing beauty, empowering professionals
            </h2>
            <p className="text-ink-soft leading-relaxed text-base mb-8">{BRAND.description}</p>
            <Link to="/academy" className="inline-flex items-center gap-2 text-ink font-medium border-b-2 border-gold pb-1 hover:gap-3 transition-all">
              Discover the Academy <ArrowRight size={16} />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* FEATURED SERVICES */}
      <section className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Reveal>
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
              <div>
                <p className="overline mb-4">Our Services</p>
                <h2 className="font-serif font-light text-3xl md:text-5xl text-ink max-w-lg leading-tight">Signature salon experiences</h2>
              </div>
              <Link to="/services" data-testid="explore-services-btn" className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-7 py-3.5 text-sm font-medium hover:bg-gold transition-colors self-start">
                Explore All Services <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURED_SERVICES.map((s, i) => (
              <Reveal key={s.title} delay={i * 90}>
                <div className="group rounded-2xl border border-line bg-white hover:shadow-xl transition-shadow duration-500">
                  <div className="p-6">
                    <Scissors size={18} className="text-gold mb-3" strokeWidth={1.4} />
                    <h3 className="font-serif text-xl text-ink mb-2">{s.title}</h3>
                    <p className="text-sm text-ink-soft leading-relaxed">{s.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* HAIR TRANSFORMATION */}
      <section className="py-24 md:py-32 bg-ink text-white">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-14 items-center">
          <Reveal>
            <div className="relative rounded-2xl overflow-hidden aspect-[9/12] max-w-md">
              <video data-testid="transformation-video" className="h-full w-full object-cover" src={MEDIA.hairTransformation} controls playsInline preload="metadata" />
            </div>
          </Reveal>
          <Reveal delay={150}>
            <p className="overline mb-4">Transformation</p>
            <h2 className="font-serif font-light text-3xl md:text-5xl leading-tight mb-6">A hair transformation worth showing off</h2>
            <p className="text-white/70 leading-relaxed mb-8">Experience expert styling, smoothing and colour crafted to reveal your best self. Watch the magic unfold and book your own transformation today.</p>
            <a href={WHATSAPP.salonBooking()} target="_blank" rel="noreferrer" data-testid="book-transformation-btn" className="inline-flex items-center gap-2 rounded-full bg-gold text-white px-8 py-4 text-sm font-medium hover:bg-gold-hover transition-colors">
              Book Your Transformation <ArrowRight size={16} />
            </a>
          </Reveal>
        </div>
      </section>

      {/* GALLERY PREVIEW */}
      <section className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Reveal>
            <div className="text-center mb-14">
              <p className="overline mb-4">Gallery</p>
              <h2 className="font-serif font-light text-3xl md:text-5xl text-ink">Moments of beauty</h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {GALLERY.slice(0, 6).map((img, i) => (
              <Reveal key={img} delay={i * 70}>
                <div className={`overflow-hidden rounded-xl ${i % 3 === 0 ? "row-span-2 h-full" : ""}`}>
                  <img src={img} alt="salon work" loading="lazy" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700 min-h-[220px]" />
                </div>
              </Reveal>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/services" data-testid="view-gallery-btn" className="inline-flex items-center gap-2 rounded-full border border-ink px-8 py-4 text-sm font-medium hover:bg-ink hover:text-white transition-colors">
              View Full Gallery <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* TESTIMONIAL PREVIEW */}
      <section className="py-24 md:py-32 bg-surface">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Reveal>
            <div className="text-center mb-14">
              <p className="overline mb-4">Kind Words</p>
              <h2 className="font-serif font-light text-3xl md:text-5xl text-ink">What our clients say</h2>
            </div>
          </Reveal>
          <div className="grid sm:grid-cols-3 gap-6">
            {TESTIMONIAL_VIDEOS.slice(0, 3).map((v, i) => (
              <Reveal key={v} delay={i * 100}>
                <div className="rounded-2xl overflow-hidden border border-line bg-black aspect-[9/14]">
                  <video className="h-full w-full object-cover" src={v} poster={videoPoster(v, 1)} controls playsInline preload="metadata" />
                </div>
              </Reveal>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/reviews" data-testid="view-reviews-btn" className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-8 py-4 text-sm font-medium hover:bg-gold transition-colors">
              View All Reviews <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA STRIP */}
      <section className="py-20 bg-gold text-white text-center px-5">
        <Reveal>
          <GraduationCap className="mx-auto mb-5" size={38} strokeWidth={1.3} />
          <h2 className="font-serif font-light text-3xl md:text-4xl mb-4">Start your beauty career today</h2>
          <p className="text-white/85 max-w-xl mx-auto mb-8">Join our industry-focused courses and masterclasses designed to make you a confident professional.</p>
          <Link to="/academy" className="inline-flex items-center gap-2 rounded-full bg-white text-ink px-8 py-4 text-sm font-medium hover:bg-ink hover:text-white transition-colors">
            Explore Courses <ArrowRight size={16} />
          </Link>
        </Reveal>
      </section>
    </div>
  );
}
