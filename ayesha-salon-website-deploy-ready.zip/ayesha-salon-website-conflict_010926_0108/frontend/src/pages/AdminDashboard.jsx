import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { LogOut, Users, BookOpen, Sparkles, Settings, Save, Trash2, Plus } from "lucide-react";
import api from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { BRAND } from "../lib/data";
import { toast } from "sonner";

const TABS = [
  { id: "students", label: "Students", icon: Users },
  { id: "courses", label: "Courses", icon: BookOpen },
  { id: "masterclasses", label: "Masterclasses", icon: Sparkles },
  { id: "settings", label: "Settings", icon: Settings },
];

const input = "w-full rounded-lg border border-line bg-white px-3 py-2.5 text-sm outline-none focus:border-gold focus:ring-1 focus:ring-gold";
const label = "text-xs text-ink-soft uppercase tracking-wide mb-1 block";

export default function AdminDashboard() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState("students");
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [mcs, setMcs] = useState([]);
  const [config, setConfig] = useState({});

  const load = () => {
    api.get("/admin/students").then((r) => setStudents(r.data)).catch(() => {});
    api.get("/admin/courses").then((r) => setCourses(r.data)).catch(() => {});
    api.get("/masterclasses").then((r) => setMcs(r.data)).catch(() => {});
    api.get("/admin/config").then((r) => setConfig(r.data)).catch(() => {});
  };
  useEffect(load, []);

  const doLogout = async () => { await logout(); navigate("/"); };

  const saveCourse = async (c) => {
    try { await api.put(`/admin/courses/${c.id}`, c); toast.success("Course saved"); }
    catch { toast.error("Save failed"); }
  };
  const saveMc = async (m) => {
    try { await api.put(`/admin/masterclasses/${m.id}`, { name: m.name, description: m.description, features: m.features, price: m.price === "" ? null : Number(m.price), image: m.image, active: true }); toast.success("Masterclass saved"); }
    catch { toast.error("Save failed"); }
  };
  const saveConfig = async () => {
    try { await api.put("/admin/config", config); toast.success("Settings saved"); }
    catch { toast.error("Save failed"); }
  };

  const setCourse = (id, patch) => setCourses(courses.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  const setLecture = (cid, lid, patch) => setCourses(courses.map((c) => c.id === cid ? { ...c, lectures: c.lectures.map((l) => l.id === lid ? { ...l, ...patch } : l) } : c));
  const setMcState = (id, patch) => setMcs(mcs.map((m) => (m.id === id ? { ...m, ...patch } : m)));

  return (
    <div className="min-h-screen bg-surface" data-testid="admin-dashboard">
      <header className="bg-ink text-white">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={BRAND.logo} alt="logo" className="h-10 w-10 rounded-full object-cover" />
            <span className="font-serif text-lg">Admin Dashboard</span>
          </div>
          <button data-testid="admin-logout-btn" onClick={doLogout} className="inline-flex items-center gap-2 text-sm text-white/70 hover:text-white"><LogOut size={16} /> Logout</button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-5 md:px-8 py-8 grid md:grid-cols-[220px_1fr] gap-8">
        <aside className="flex md:flex-col gap-2 overflow-x-auto">
          {TABS.map((t) => (
            <button key={t.id} data-testid={`admin-tab-${t.id}`} onClick={() => setTab(t.id)} className={`flex items-center gap-2.5 rounded-lg px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors ${tab === t.id ? "bg-gold text-white" : "bg-white text-ink-soft hover:text-ink border border-line"}`}>
              <t.icon size={17} strokeWidth={1.6} /> {t.label}
            </button>
          ))}
        </aside>

        <main>
          {tab === "students" && (
            <div data-testid="students-panel">
              <h2 className="font-serif text-2xl text-ink mb-6">Students ({students.length})</h2>
              <div className="bg-white rounded-2xl border border-line overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-ink-soft border-b border-line"><th className="p-4">Name</th><th className="p-4">Email</th><th className="p-4">Phone</th><th className="p-4">Purchases</th></tr></thead>
                  <tbody>
                    {students.map((s) => (
                      <tr key={s.id} className="border-b border-line/60">
                        <td className="p-4 font-medium text-ink">{s.name}</td>
                        <td className="p-4 text-ink-soft">{s.email}</td>
                        <td className="p-4 text-ink-soft">{s.phone || "—"}</td>
                        <td className="p-4">
                          {s.purchases.length === 0 ? <span className="text-ink-soft">None</span> : s.purchases.map((p) => (
                            <div key={p.item_id} className="text-xs mb-1"><span className="text-ink font-medium">{p.name}</span> · <span className={p.active ? "text-green-600" : "text-red-500"}>{p.active ? `${p.remaining_days}d left` : "Expired"}</span></div>
                          ))}
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && <tr><td colSpan="4" className="p-8 text-center text-ink-soft">No students yet.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === "courses" && (
            <div data-testid="courses-panel" className="space-y-6">
              <h2 className="font-serif text-2xl text-ink">Courses</h2>
              {courses.map((c) => (
                <div key={c.id} className="bg-white rounded-2xl border border-line p-6">
                  <div className="grid sm:grid-cols-2 gap-4 mb-4">
                    <div><label className={label}>Name</label><input className={input} value={c.name} onChange={(e) => setCourse(c.id, { name: e.target.value })} /></div>
                    <div><label className={label}>Price (₹)</label><input type="number" className={input} value={c.price} onChange={(e) => setCourse(c.id, { price: Number(e.target.value) })} /></div>
                    <div className="sm:col-span-2"><label className={label}>Description</label><textarea className={input} rows="2" value={c.description} onChange={(e) => setCourse(c.id, { description: e.target.value })} /></div>
                    <div className="sm:col-span-2"><label className={label}>Salon Academy Google Meet Link (live class)</label><input className={input} value={c.meet_link || ""} onChange={(e) => setCourse(c.id, { meet_link: e.target.value })} placeholder="https://meet.google.com/..." /></div>
                  </div>
                  <label className={label}>Lecture Video URLs</label>
                  <div className="space-y-2 mb-4">
                    {(c.lectures || []).map((l) => (
                      <div key={l.id} className="flex gap-2 items-center">
                        <span className="text-xs text-ink-soft w-40 shrink-0 truncate">{l.title}</span>
                        <input className={input} value={l.video_url || ""} onChange={(e) => setLecture(c.id, l.id, { video_url: e.target.value })} placeholder="Video URL" />
                      </div>
                    ))}
                  </div>
                  <button data-testid="save-course-btn" onClick={() => saveCourse(c)} className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-6 py-2.5 text-sm font-medium hover:bg-gold transition-colors"><Save size={15} /> Save</button>
                </div>
              ))}
            </div>
          )}

          {tab === "masterclasses" && (
            <div data-testid="masterclasses-panel" className="space-y-6">
              <h2 className="font-serif text-2xl text-ink">Masterclasses</h2>
              {mcs.map((m) => (
                <div key={m.id} className="bg-white rounded-2xl border border-line p-6 flex flex-col sm:flex-row gap-5">
                  <img src={m.image} alt={m.name} className="w-full sm:w-28 h-28 object-cover rounded-lg" />
                  <div className="flex-1 grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2"><label className={label}>Name</label><input className={input} value={m.name} onChange={(e) => setMcState(m.id, { name: e.target.value })} /></div>
                    <div className="sm:col-span-2"><label className={label}>Description</label><textarea className={input} rows="2" value={m.description} onChange={(e) => setMcState(m.id, { description: e.target.value })} /></div>
                    <div><label className={label}>Price (₹) — leave empty to hide</label><input type="number" className={input} value={m.price ?? ""} onChange={(e) => setMcState(m.id, { price: e.target.value === "" ? null : Number(e.target.value) })} /></div>
                    <div className="flex items-end"><button data-testid="save-mc-btn" onClick={() => saveMc(m)} className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-6 py-2.5 text-sm font-medium hover:bg-gold transition-colors"><Save size={15} /> Save</button></div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "settings" && (
            <div data-testid="settings-panel" className="bg-white rounded-2xl border border-line p-7 max-w-2xl">
              <h2 className="font-serif text-2xl text-ink mb-6">External Links & Configuration</h2>
              <div className="space-y-4">
                {[
                  ["hero_video_url", "Salon Hero Video URL"],
                  ["google_maps_link", "Google Maps Link (Get Directions)"],
                  ["google_review_link", "Google Review Link (Leave a Review)"],
                  ["salon_meet_link", "Salon Academy Google Meet Link"],
                  ["fitness_meet_link", "Fitness Coaching Google Meet Link"],
                  ["phonepe_merchant_id", "PhonePe Merchant ID"],
                  ["phonepe_client_id", "PhonePe Client ID"],
                  ["phonepe_client_secret", "PhonePe Client Secret"],
                ].map(([k, lbl]) => (
                  <div key={k}><label className={label}>{lbl}</label><input data-testid={`config-${k}`} className={input} value={config[k] || ""} onChange={(e) => setConfig({ ...config, [k]: e.target.value })} /></div>
                ))}
              </div>
              <button data-testid="save-config-btn" onClick={saveConfig} className="inline-flex items-center gap-2 rounded-full bg-ink text-white px-7 py-3 text-sm font-medium hover:bg-gold transition-colors mt-6"><Save size={15} /> Save Settings</button>
              <p className="text-xs text-ink-soft mt-4">PhonePe payments run in MOCK mode until valid credentials are added and live mode is enabled on the server.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
