import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { LogOut, Clock, CheckCircle2, XCircle, Video, Radio, GraduationCap } from "lucide-react";
import api from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { BRAND } from "../lib/data";
import { toast } from "sonner";

export default function StudentDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [access, setAccess] = useState([]);
  const [content, setContent] = useState(null);

  useEffect(() => { api.get("/my/access").then((r) => setAccess(r.data)).catch(() => {}); }, []);

  const openContent = async (item) => {
    try {
      const { data } = await api.get(`/my/courses/${item.item_id}/content`);
      setContent(data);
    } catch (e) {
      toast.error(e.response?.data?.detail || "Access denied");
    }
  };

  const doLogout = async () => { await logout(); navigate("/"); };

  return (
    <div className="min-h-screen bg-surface" data-testid="student-dashboard">
      <header className="bg-white border-b border-line">
        <div className="max-w-6xl mx-auto px-5 md:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={BRAND.logo} alt="logo" className="h-10 w-10 rounded-full object-cover" />
            <span className="font-serif text-lg text-ink">Student Portal</span>
          </div>
          <button data-testid="logout-btn" onClick={doLogout} className="inline-flex items-center gap-2 text-sm text-ink-soft hover:text-ink"><LogOut size={16} /> Logout</button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-5 md:px-8 py-12">
        <h1 className="font-serif font-light text-3xl md:text-4xl text-ink mb-2">Welcome, {user?.name}</h1>
        <p className="text-ink-soft mb-10">Manage your enrolled courses and access your content.</p>

        {access.length === 0 ? (
          <div className="bg-white rounded-2xl border border-line p-12 text-center">
            <GraduationCap className="mx-auto text-gold mb-4" size={44} strokeWidth={1.2} />
            <p className="text-ink font-medium mb-2">No courses yet</p>
            <p className="text-ink-soft text-sm mb-6">Explore the academy and enrol in a course to get started.</p>
            <button onClick={() => navigate("/academy")} className="rounded-full bg-ink text-white px-7 py-3 text-sm font-medium hover:bg-gold transition-colors">Browse Courses</button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {access.map((a) => (
              <div key={`${a.item_type}-${a.item_id}`} data-testid="access-card" className="bg-white rounded-2xl border border-line p-7">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-serif text-2xl text-ink pr-4">{a.name}</h3>
                  <span className={`shrink-0 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${a.active ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>
                    {a.active ? <CheckCircle2 size={13} /> : <XCircle size={13} />} {a.active ? "Active" : "Expired"}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm mb-5">
                  <div><p className="text-ink-soft text-xs uppercase tracking-wide">Payment</p><p className="text-ink font-medium">Paid</p></div>
                  <div><p className="text-ink-soft text-xs uppercase tracking-wide">Remaining</p><p className="text-ink font-medium flex items-center gap-1"><Clock size={13} className="text-gold" /> {a.remaining_days} days</p></div>
                  <div><p className="text-ink-soft text-xs uppercase tracking-wide">Start Date</p><p className="text-ink font-medium">{a.start_date ? new Date(a.start_date).toLocaleDateString() : "—"}</p></div>
                  <div><p className="text-ink-soft text-xs uppercase tracking-wide">Expiry Date</p><p className="text-ink font-medium">{new Date(a.expiry_date).toLocaleDateString()}</p></div>
                </div>
                {a.item_type !== "masterclass" && (
                  <button data-testid="view-content-btn" disabled={!a.active} onClick={() => openContent(a)} className="w-full rounded-full bg-ink text-white py-3 text-sm font-medium hover:bg-gold transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                    {a.active ? "View Course Content" : "Access Expired"}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {content && (
        <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm grid place-items-center p-4" onClick={() => setContent(null)} data-testid="content-modal">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-8" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-serif text-2xl text-ink">{content.name}</h2>
              <button onClick={() => setContent(null)} className="text-ink-soft hover:text-ink"><XCircle size={24} /></button>
            </div>
            {content.meet_link && (
              <a href={content.meet_link} target="_blank" rel="noreferrer" data-testid="join-live-btn" className="flex items-center justify-center gap-2 rounded-full bg-gold text-white py-3.5 text-sm font-medium hover:bg-gold-hover transition-colors mb-6">
                <Radio size={16} /> Join Live Class
              </a>
            )}
            <p className="overline mb-4">Course Modules</p>
            <div className="space-y-3">
              {content.lectures.map((l, i) => (
                <div key={l.id} className="rounded-xl border border-line p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="h-8 w-8 grid place-items-center rounded-full bg-cream text-gold text-sm font-medium">{i + 1}</span>
                    <div><p className="font-medium text-ink text-sm">{l.title}</p><p className="text-xs text-ink-soft">{l.description}</p></div>
                  </div>
                  {l.video_url ? (
                    <video className="w-full rounded-lg mt-2" src={l.video_url} controls preload="none" />
                  ) : (
                    <p className="flex items-center gap-2 text-xs text-ink-soft mt-2 pl-11"><Video size={13} /> Recording coming soon</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
