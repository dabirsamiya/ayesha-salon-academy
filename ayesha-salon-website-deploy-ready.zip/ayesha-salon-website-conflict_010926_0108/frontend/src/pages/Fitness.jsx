import { Dumbbell, ArrowRight, Instagram, Facebook, Youtube, Phone, Clock, Radio } from "lucide-react";
import { CONTACT, SOCIAL, WHATSAPP, MEDIA, YOGA_VIDEO, MEET, videoPoster } from "../lib/data";
import Reveal from "../components/Reveal";

const PROGRAMS = [
  { t: "1-on-1 Personal Coaching", d: "Personalised training plans built around your goals, lifestyle and body." },
  { t: "Online Coaching", d: "Remote guidance, custom workouts and nutrition support wherever you are." },
  { t: "Transformation Programs", d: "Structured multi-week programs designed for real, lasting results." },
];

export default function Fitness() {
  return (
    <div data-testid="fitness-page">
      {/* HERO */}
      <section className="relative h-[85vh] min-h-[560px] overflow-hidden">
        <img src={MEDIA.fitnessHero} alt="Fitness Coach Rehan" className="absolute inset-0 h-full w-full object-cover object-top" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/30" />
        <div className="relative z-10 h-full flex flex-col justify-center max-w-7xl mx-auto px-5 md:px-8">
          <Reveal>
            <p className="overline text-gold mb-4">Fitness Coaching</p>
            <h1 className="font-serif font-light text-white text-4xl sm:text-5xl lg:text-7xl max-w-2xl leading-[1.05]">
              Train with <span className="italic text-gold">Coach Rehan</span>
            </h1>
            <p className="text-white/80 max-w-lg mt-6 leading-relaxed">
              Build strength, confidence and discipline with expert coaching tailored to your goals. Your transformation starts here.
            </p>
            <div className="flex flex-wrap gap-4 mt-8">
              <a href={WHATSAPP.fitness()} target="_blank" rel="noreferrer" data-testid="fitness-whatsapp-btn" className="inline-flex items-center gap-2 rounded-full bg-gold text-white px-8 py-4 text-sm font-medium hover:bg-gold-hover transition-colors">
                Enquire on WhatsApp <ArrowRight size={16} />
              </a>
              <a href={`tel:${CONTACT.fitnessPhoneRaw}`} data-testid="fitness-call-btn" className="inline-flex items-center gap-2 rounded-full border border-white/60 text-white px-8 py-4 text-sm font-medium hover:bg-white hover:text-ink transition-colors">
                <Phone size={16} /> {CONTACT.fitnessPhone}
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* INTRO */}
      <section className="py-20 md:py-28">
        <div className="max-w-5xl mx-auto px-5 md:px-8 text-center">
          <Reveal>
            <Dumbbell className="mx-auto text-gold mb-6" size={40} strokeWidth={1.2} />
            <h2 className="font-serif font-light text-3xl md:text-5xl text-ink leading-tight mb-6">Coaching that meets you where you are</h2>
            <p className="text-ink-soft max-w-2xl mx-auto leading-relaxed">
              Whether you're just starting out or pushing towards your peak, Coach Rehan delivers structured, motivating and results-driven fitness coaching for every level.
            </p>
          </Reveal>
        </div>
      </section>

      {/* PROGRAMS */}
      <section className="pb-20 md:pb-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            {PROGRAMS.map((p, i) => (
              <Reveal key={p.t} delay={i * 100}>
                <div className="rounded-2xl border border-line bg-white p-8 hover:shadow-xl transition-shadow duration-500 h-full">
                  <Dumbbell className="text-gold mb-4" size={26} strokeWidth={1.4} />
                  <h3 className="font-serif text-2xl text-ink mb-3">{p.t}</h3>
                  <p className="text-sm text-ink-soft leading-relaxed mb-6">{p.d}</p>
                  <a href={WHATSAPP.fitness()} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-ink font-medium border-b-2 border-gold pb-1 hover:gap-3 transition-all text-sm">
                    Enquire Now <ArrowRight size={14} />
                  </a>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FREE YOGA */}
      <section className="py-20 md:py-28 bg-surface">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-14 items-center">
          <Reveal>
            <div className="rounded-2xl overflow-hidden aspect-[9/12] max-w-md bg-black">
              <video data-testid="yoga-video" className="h-full w-full object-cover" src={YOGA_VIDEO} poster={videoPoster(YOGA_VIDEO, 2)} controls playsInline preload="metadata" />
            </div>
          </Reveal>
          <Reveal delay={150}>
            <p className="overline mb-4">Free Session</p>
            <h2 className="font-serif font-light text-3xl md:text-5xl text-ink leading-tight mb-5">Start Your Fitness Journey — Free Yoga Session</h2>
            <p className="text-ink-soft leading-relaxed mb-8">Watch our free yoga introduction and experience the first step towards a healthier, stronger you — completely free, on any device.</p>
            <a href={MEET.fitness} target="_blank" rel="noreferrer" data-testid="fitness-live-btn" className="inline-flex items-center gap-2 rounded-full bg-red-600 text-white px-8 py-4 text-sm font-medium hover:bg-red-700 transition-colors shadow-lg">
              <Radio size={16} /> Join Fitness Live Class
            </a>
          </Reveal>
        </div>
      </section>

      {/* COMING SOON */}
      <section className="py-20 bg-ink text-white text-center px-5">
        <Reveal>
          <Clock className="mx-auto text-gold mb-5" size={34} strokeWidth={1.3} />
          <h2 className="font-serif font-light text-3xl md:text-4xl mb-4">Fitness Programs & Video Content</h2>
          <p className="text-gold text-lg mb-3">Coming Soon</p>
          <p className="text-white/60 max-w-xl mx-auto">Paid fitness video programs and live online classes will be available here soon. Enquire on WhatsApp to be the first to know.</p>
        </Reveal>
      </section>

      {/* SOCIAL */}
      <section className="py-16 text-center">
        <Reveal>
          <p className="overline mb-6">Follow Coach Rehan</p>
          <div className="flex justify-center gap-4">
            <a href={SOCIAL.fitness.instagram} target="_blank" rel="noreferrer" data-testid="fitness-instagram" className="h-12 w-12 grid place-items-center rounded-full border border-line hover:border-gold hover:text-gold transition-colors"><Instagram size={19} strokeWidth={1.5} /></a>
            <a href={SOCIAL.fitness.facebook} target="_blank" rel="noreferrer" data-testid="fitness-facebook" className="h-12 w-12 grid place-items-center rounded-full border border-line hover:border-gold hover:text-gold transition-colors"><Facebook size={19} strokeWidth={1.5} /></a>
            <a href={SOCIAL.fitness.youtube} target="_blank" rel="noreferrer" data-testid="fitness-youtube" className="h-12 w-12 grid place-items-center rounded-full border border-line hover:border-gold hover:text-gold transition-colors"><Youtube size={19} strokeWidth={1.5} /></a>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
