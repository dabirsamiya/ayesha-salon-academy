import { useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { formatApiError } from "../lib/api";
import { BRAND } from "../lib/data";
import { toast } from "sonner";

export default function Login() {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [busy, setBusy] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const redirect = params.get("redirect") || "";

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const u = mode === "login"
        ? await login(form.email, form.password)
        : await register(form);
      toast.success(mode === "login" ? "Welcome back!" : "Account created!");
      if (redirect) navigate(redirect);
      else navigate(u.role === "admin" ? "/admin" : "/dashboard");
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="min-h-screen grid md:grid-cols-2" data-testid="login-page">
      <div className="hidden md:block relative">
        <img src="https://images.pexels.com/photos/3985360/pexels-photo-3985360.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1200" alt="salon" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-ink/60" />
        <div className="relative z-10 h-full flex flex-col justify-end p-12 text-white">
          <img src={BRAND.logo} alt="logo" className="h-16 w-16 rounded-full object-cover ring-2 ring-gold/60 mb-6" />
          <h2 className="font-serif font-light text-4xl leading-tight mb-3">Learn. Create. Grow.</h2>
          <p className="text-white/70 max-w-sm">Access your courses, lectures and live classes in one place.</p>
        </div>
      </div>

      <div className="flex items-center justify-center p-6 md:p-12 bg-surface">
        <div className="w-full max-w-md">
          <Link to="/" className="inline-flex items-center gap-2 mb-8">
            <img src={BRAND.logo} alt="logo" className="h-10 w-10 rounded-full object-cover md:hidden" />
            <span className="font-serif text-xl text-ink">Ayesha Salon & Academy</span>
          </Link>
          <h1 className="font-serif font-light text-3xl text-ink mb-2">{mode === "login" ? "Student Login" : "Create your account"}</h1>
          <p className="text-ink-soft text-sm mb-8">{mode === "login" ? "Sign in to access your dashboard." : "Register to enrol in courses."}</p>

          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <input data-testid="name-input" required value={form.name} onChange={set("name")} placeholder="Full name" className="w-full rounded-lg border border-line bg-white px-4 py-3.5 text-sm outline-none focus:border-gold focus:ring-1 focus:ring-gold" />
            )}
            <input data-testid="email-input" required type="email" value={form.email} onChange={set("email")} placeholder="Email address" className="w-full rounded-lg border border-line bg-white px-4 py-3.5 text-sm outline-none focus:border-gold focus:ring-1 focus:ring-gold" />
            {mode === "register" && (
              <input data-testid="phone-input" value={form.phone} onChange={set("phone")} placeholder="Phone number" className="w-full rounded-lg border border-line bg-white px-4 py-3.5 text-sm outline-none focus:border-gold focus:ring-1 focus:ring-gold" />
            )}
            <input data-testid="password-input" required type="password" value={form.password} onChange={set("password")} placeholder="Password (min 6 chars)" className="w-full rounded-lg border border-line bg-white px-4 py-3.5 text-sm outline-none focus:border-gold focus:ring-1 focus:ring-gold" />
            <button data-testid="auth-submit-btn" disabled={busy} type="submit" className="w-full rounded-full bg-ink text-white py-4 text-sm font-medium hover:bg-gold transition-colors disabled:opacity-60">
              {busy ? "Please wait…" : mode === "login" ? "Sign In" : "Create Account"}
            </button>
          </form>

          <p className="text-center text-sm text-ink-soft mt-6">
            {mode === "login" ? "New here? " : "Already have an account? "}
            <button data-testid="toggle-auth-mode" onClick={() => setMode(mode === "login" ? "register" : "login")} className="text-gold font-medium hover:underline">
              {mode === "login" ? "Create an account" : "Sign in"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
