from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import os
import logging
import secrets
import uuid
from datetime import datetime, timezone, timedelta
from typing import List, Optional

import bcrypt
import jwt
import httpx
from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr
from bson import ObjectId

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALGORITHM = "HS256"
ACCESS_DAYS = int(os.environ.get('COURSE_ACCESS_DAYS', '30'))
APP_MODE = os.environ.get('APP_MODE', 'mock')

app = FastAPI()
api = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ayesha")


def now_utc():
    return datetime.now(timezone.utc)


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def create_access_token(user_id: str, email: str, role: str) -> str:
    payload = {
        "sub": user_id, "email": email, "role": role,
        "exp": now_utc() + timedelta(days=7), "type": "access",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class RegisterInput(BaseModel):
    name: str
    email: EmailStr
    phone: str = ""
    password: str = Field(min_length=6)


class LoginInput(BaseModel):
    email: EmailStr
    password: str


class Lecture(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str = ""
    video_url: str = ""


class CourseInput(BaseModel):
    name: str
    description: str = ""
    features: List[str] = []
    price: float = 0
    duration_days: int = 30
    image: str = ""
    type: str = "academy"  # academy | fitness
    meet_link: str = ""
    duration_label: str = ""
    certificate_text: str = ""
    lectures: List[Lecture] = []
    active: bool = True


class MasterclassInput(BaseModel):
    name: str
    description: str = ""
    features: List[str] = []
    price: Optional[float] = None
    image: str = ""
    active: bool = True


class ConfigInput(BaseModel):
    hero_video_url: Optional[str] = None
    google_maps_link: Optional[str] = None
    google_review_link: Optional[str] = None
    salon_meet_link: Optional[str] = None
    fitness_meet_link: Optional[str] = None
    phonepe_merchant_id: Optional[str] = None
    phonepe_client_id: Optional[str] = None
    phonepe_client_secret: Optional[str] = None


class PaymentCreate(BaseModel):
    item_type: str  # course | masterclass | fitness
    item_id: str


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        user["id"] = str(user["_id"])
        user.pop("_id", None)
        user.pop("password_hash", None)
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


async def require_admin(user: dict = Depends(get_current_user)) -> dict:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def set_auth_cookie(response: Response, token: str):
    response.set_cookie(
        key="access_token", value=token, httponly=True, secure=True,
        samesite="none", max_age=604800, path="/",
    )


# ---------------------------------------------------------------------------
# Auth endpoints
# ---------------------------------------------------------------------------
@api.post("/auth/register")
async def register(body: RegisterInput, response: Response):
    email = body.email.lower()
    if await db.users.find_one({"email": email}):
        raise HTTPException(status_code=400, detail="Email already registered")
    doc = {
        "name": body.name, "email": email, "phone": body.phone,
        "password_hash": hash_password(body.password), "role": "student",
        "created_at": now_utc().isoformat(),
    }
    res = await db.users.insert_one(doc)
    uid = str(res.inserted_id)
    token = create_access_token(uid, email, "student")
    set_auth_cookie(response, token)
    return {"id": uid, "name": body.name, "email": email, "role": "student", "token": token}


@api.post("/auth/login")
async def login(body: LoginInput, response: Response):
    email = body.email.lower()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    uid = str(user["_id"])
    token = create_access_token(uid, email, user.get("role", "student"))
    set_auth_cookie(response, token)
    return {"id": uid, "name": user["name"], "email": email, "role": user.get("role", "student"), "token": token}


@api.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    return {"ok": True}


@api.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return user


# ---------------------------------------------------------------------------
# Public content
# ---------------------------------------------------------------------------
def public_course(c: dict) -> dict:
    return {
        "id": c["id"], "name": c["name"], "description": c.get("description", ""),
        "features": c.get("features", []), "price": c.get("price", 0),
        "duration_days": c.get("duration_days", 30), "image": c.get("image", ""),
        "duration_label": c.get("duration_label", ""), "certificate_text": c.get("certificate_text", ""),
        "type": c.get("type", "academy"),
        "lecture_count": len(c.get("lectures", [])),
    }


@api.get("/courses")
async def list_courses(type: str = "academy"):
    docs = await db.courses.find({"type": type, "active": True}, {"_id": 0}).to_list(100)
    return [public_course(c) for c in docs]


@api.get("/masterclasses")
async def list_masterclasses():
    docs = await db.masterclasses.find({"active": True}, {"_id": 0}).to_list(100)
    return docs


@api.get("/config")
async def public_config():
    cfg = await db.config.find_one({"id": "site"}, {"_id": 0}) or {}
    return {
        "hero_video_url": cfg.get("hero_video_url", ""),
        "google_maps_link": cfg.get("google_maps_link", ""),
        "google_review_link": cfg.get("google_review_link", ""),
    }


# ---------------------------------------------------------------------------
# Payments (mock-ready PhonePe architecture)
# ---------------------------------------------------------------------------
async def get_item(item_type: str, item_id: str):
    if item_type in ("course", "fitness"):
        return await db.courses.find_one({"id": item_id}, {"_id": 0})
    if item_type == "masterclass":
        return await db.masterclasses.find_one({"id": item_id}, {"_id": 0})
    return None


async def grant_access(user_id: str, item_type: str, item_id: str, order: str, amount: int):
    now = now_utc()
    item = await get_item(item_type, item_id)
    days = int((item or {}).get("duration_days") or ACCESS_DAYS)
    expires = now + timedelta(days=days)
    await db.payments.update_one(
        {"merchant_order_id": order},
        {"$set": {"state": "COMPLETED", "verified_at": now.isoformat(), "amount": amount},
         "$setOnInsert": {"user_id": user_id, "item_type": item_type, "item_id": item_id}},
        upsert=True,
    )
    await db.course_access.update_one(
        {"user_id": user_id, "item_type": item_type, "item_id": item_id},
        {"$set": {"granted_by_payment": order, "expires_at": expires.isoformat(),
                  "start_date": now.isoformat(), "updated_at": now.isoformat()},
         "$setOnInsert": {"user_id": user_id, "item_type": item_type, "item_id": item_id, "created_at": now.isoformat()}},
        upsert=True,
    )


@api.post("/payments/create")
async def create_payment(body: PaymentCreate, user: dict = Depends(get_current_user)):
    item = await get_item(body.item_type, body.item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    price = item.get("price")
    if not price or price <= 0:
        raise HTTPException(status_code=400, detail="Pricing not available for this item yet")
    amount = int(round(price * 100))
    order = f"AYESHA_{secrets.token_hex(8)}"[:63]
    await db.payments.insert_one({
        "merchant_order_id": order, "user_id": user["id"], "item_type": body.item_type,
        "item_id": body.item_id, "amount": amount, "state": "PENDING",
        "created_at": now_utc().isoformat(),
    })
    if APP_MODE == "mock":
        return {"mode": "mock", "merchant_order_id": order,
                "checkout_url": f"/payment-result?order={order}"}
    # Real PhonePe branch (requires configured credentials) — not active until keys added.
    raise HTTPException(status_code=503, detail="Live payments not configured yet")


@api.post("/payments/{order}/mock-complete")
async def mock_complete(order: str, user: dict = Depends(get_current_user)):
    if APP_MODE != "mock":
        raise HTTPException(status_code=404, detail="Mock disabled")
    p = await db.payments.find_one({"merchant_order_id": order})
    if not p:
        raise HTTPException(status_code=404, detail="Order not found")
    if p["user_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="Not your order")
    await grant_access(p["user_id"], p["item_type"], p["item_id"], order, p["amount"])
    return {"state": "COMPLETED"}


@api.get("/payments/{order}")
async def payment_status(order: str, user: dict = Depends(get_current_user)):
    p = await db.payments.find_one({"merchant_order_id": order}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Not found")
    access = await db.course_access.find_one(
        {"user_id": p["user_id"], "item_type": p["item_type"], "item_id": p["item_id"],
         "expires_at": {"$gt": now_utc().isoformat()}})
    return {"state": p["state"], "access": bool(access), "item_type": p["item_type"], "item_id": p["item_id"]}


# ---------------------------------------------------------------------------
# Student area
# ---------------------------------------------------------------------------
def access_view(a: dict, item: dict) -> dict:
    expires = datetime.fromisoformat(a["expires_at"])
    now = now_utc()
    delta = expires - now
    remaining = delta.days + (1 if delta.days >= 0 and delta.seconds > 0 else 0)
    return {
        "item_type": a["item_type"], "item_id": a["item_id"],
        "name": item.get("name", "Unknown") if item else "Unknown",
        "image": item.get("image", "") if item else "",
        "start_date": a.get("start_date"), "expiry_date": a["expires_at"],
        "remaining_days": max(remaining, 0), "active": expires > now,
    }


@api.get("/my/access")
async def my_access(user: dict = Depends(get_current_user)):
    accesses = await db.course_access.find({"user_id": user["id"]}, {"_id": 0}).to_list(100)
    out = []
    for a in accesses:
        item = await get_item(a["item_type"], a["item_id"])
        out.append(access_view(a, item))
    return out


@api.get("/my/courses/{item_id}/content")
async def course_content(item_id: str, user: dict = Depends(get_current_user)):
    course = await db.courses.find_one({"id": item_id}, {"_id": 0})
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    access = await db.course_access.find_one({
        "user_id": user["id"], "item_type": {"$in": ["course", "fitness"]}, "item_id": item_id,
        "expires_at": {"$gt": now_utc().isoformat()}})
    if not access and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Course access expired or not purchased")
    cfg = await db.config.find_one({"id": "site"}, {"_id": 0}) or {}
    meet = cfg.get("fitness_meet_link", "") if course.get("type") == "fitness" else cfg.get("salon_meet_link", "")
    return {
        "id": course["id"], "name": course["name"], "type": course.get("type"),
        "lectures": course.get("lectures", []),
        "meet_link": course.get("meet_link") or meet,
    }


# ---------------------------------------------------------------------------
# Admin area
# ---------------------------------------------------------------------------
@api.get("/admin/config")
async def admin_get_config(_: dict = Depends(require_admin)):
    cfg = await db.config.find_one({"id": "site"}, {"_id": 0}) or {}
    return cfg


@api.put("/admin/config")
async def admin_update_config(body: ConfigInput, _: dict = Depends(require_admin)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    await db.config.update_one({"id": "site"}, {"$set": updates}, upsert=True)
    return await db.config.find_one({"id": "site"}, {"_id": 0})


@api.get("/admin/students")
async def admin_students(_: dict = Depends(require_admin)):
    users = await db.users.find({"role": "student"}).to_list(1000)
    out = []
    for u in users:
        uid = str(u["_id"])
        accesses = await db.course_access.find({"user_id": uid}, {"_id": 0}).to_list(100)
        acc_views = []
        for a in accesses:
            item = await get_item(a["item_type"], a["item_id"])
            acc_views.append(access_view(a, item))
        out.append({
            "id": uid, "name": u.get("name"), "email": u.get("email"),
            "phone": u.get("phone", ""), "created_at": u.get("created_at"),
            "purchases": acc_views,
        })
    return out


@api.post("/admin/courses")
async def admin_create_course(body: CourseInput, _: dict = Depends(require_admin)):
    doc = body.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["lectures"] = [l if isinstance(l, dict) else l.model_dump() for l in doc.get("lectures", [])]
    await db.courses.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/courses/{course_id}")
async def admin_update_course(course_id: str, body: CourseInput, _: dict = Depends(require_admin)):
    updates = body.model_dump()
    updates["lectures"] = [l if isinstance(l, dict) else dict(l) for l in updates.get("lectures", [])]
    res = await db.courses.update_one({"id": course_id}, {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Course not found")
    return await db.courses.find_one({"id": course_id}, {"_id": 0})


@api.delete("/admin/courses/{course_id}")
async def admin_delete_course(course_id: str, _: dict = Depends(require_admin)):
    await db.courses.delete_one({"id": course_id})
    return {"ok": True}


@api.get("/admin/courses")
async def admin_list_courses(_: dict = Depends(require_admin)):
    return await db.courses.find({}, {"_id": 0}).to_list(200)


@api.post("/admin/masterclasses")
async def admin_create_mc(body: MasterclassInput, _: dict = Depends(require_admin)):
    doc = body.model_dump()
    doc["id"] = str(uuid.uuid4())
    await db.masterclasses.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/masterclasses/{mc_id}")
async def admin_update_mc(mc_id: str, body: MasterclassInput, _: dict = Depends(require_admin)):
    res = await db.masterclasses.update_one({"id": mc_id}, {"$set": body.model_dump()})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Masterclass not found")
    return await db.masterclasses.find_one({"id": mc_id}, {"_id": 0})


@api.delete("/admin/masterclasses/{mc_id}")
async def admin_delete_mc(mc_id: str, _: dict = Depends(require_admin)):
    await db.masterclasses.delete_one({"id": mc_id})
    return {"ok": True}


# ---------------------------------------------------------------------------
# Seeding
# ---------------------------------------------------------------------------
LANDING_VIDEO = "https://res.cloudinary.com/rimbtl5i/video/upload/v1787910301/WhatsApp_Video_2026-08-28_at_3.14.06_PM.mp4"

# Exactly four academy courses with verified cover images, pricing & duration.
COURSES_V2 = [
    {"name": "Advanced Beauty Masterclass Course", "price": 20000, "duration_days": 180,
     "duration_label": "3 to 6 Months", "certificate_text": "Government Certificate Provided",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753601/WhatsApp_Image_2026-08-26_at_6.33.51_PM.jpg",
     "features": ["Advanced Hair & Beauty Training (25+ Haircuts & Styles)", "Permanent Makeup, Microblading & Natural Brows", "Bridal Looks – Maharashtrian, Muslim & Bengali", "Korean Glass Skin, Hydra Facial & Advanced Skin", "Practice on Live Models", "Government Certificate Provided"],
     "description": "Complete professional hair & beauty training with 100% hands-on practice, expert mentors, small batches and lifetime job & business support. Covers advanced haircuts, permanent makeup, bridal looks, Korean skin and more."},
    {"name": "Professional Makeup Course", "price": 10000, "duration_days": 30,
     "duration_label": "1 Month", "certificate_text": "Government Certificate Provided",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.10_PM.jpg",
     "features": ["Bridal, Party & No-Makeup Looks", "Maharashtrian, Muslim & Bengali Looks", "Product Knowledge – National & International Brands", "Face Shapes & Colour Theory", "Practice on Live Models", "Government Certificate Provided"],
     "description": "100% practical makeup training to build skills, boost confidence and start your career. Specialised in bridal makeup with complete product knowledge and hands-on practice on live models."},
    {"name": "Advanced Aesthetic and Makeup Artistry Course", "price": 10000, "duration_days": 30,
     "duration_label": "1 Month", "certificate_text": "Government Certificate Provided",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.22_PM.jpg",
     "features": ["Advanced Aesthetics & Skin Analysis", "Dermaplaning, High-Frequency & Ultrasound", "Hydra Facial & Korean Facial", "Contouring & Preparation", "Practice on Live Models", "Government Certificate Provided"],
     "description": "100% practical training in advanced aesthetics and makeup artistry — skin analysis, dermaplaning, high-frequency, hydra & Korean facials, contouring and more, with hands-on practice on live models."},
    {"name": "Advanced Aesthetic Course", "price": 10000, "duration_days": 30,
     "duration_label": "1 Month", "certificate_text": "Government Certificate Provided",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.40_PM.jpg",
     "features": ["Advanced Aesthetics (BB Glow & more)", "Permanent Makeup – Eyeliner, Microblading & Brows", "Facial Treatments – Dermaplaning, High-Frequency, Ultrasound", "Hydra & Korean Facials", "Practice on Live Models", "Government Certificate Provided"],
     "description": "100% practical training in advanced aesthetics and permanent makeup — BB glow, permanent eyeliner, microblading, natural brows, facial treatments and Korean facials, with hands-on practice on live models."},
]

DEFAULT_COURSES = [
    {
        "name": "Complete Beautician Course",
        "description": "A comprehensive, industry-focused program covering skin, facials, clean-ups and salon fundamentals to launch your beauty career.",
        "features": ["Skin & facial techniques", "Clean-ups & bleach", "Client handling", "Certificate on completion"],
        "price": 14999, "type": "academy",
        "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753601/WhatsApp_Image_2026-08-26_at_6.33.51_PM.jpg",
    },
    {
        "name": "Professional Hair Styling Course",
        "description": "Master modern hair services — spa, smoothing, keratin and advanced treatments — with hands-on practical training.",
        "features": ["Hair spa & treatments", "Smoothing & keratin", "Styling fundamentals", "Live practice sessions"],
        "price": 17999, "type": "academy",
        "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.25.26_PM_1.mp4",
    },
    {
        "name": "Advanced Aesthetics Course",
        "description": "Learn premium facials, machine-based treatments and advanced skin aesthetics used by top salons and clinics.",
        "features": ["Hydra & premium facials", "Machine-based treatments", "Advanced skin care", "Certificate on completion"],
        "price": 21999, "type": "academy",
        "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.22_PM.jpg",
    },
]

MASTERCLASSES = [
    {"name": "Advanced Beauty Master Course",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753601/WhatsApp_Image_2026-08-26_at_6.33.51_PM.jpg",
     "description": "An intensive masterclass covering advanced beauty techniques for aspiring professionals.",
     "features": ["Advanced beauty skills", "Practical training", "Professional guidance"], "price": None},
    {"name": "Professional Makeup Course",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.22_PM.jpg",
     "description": "Learn professional makeup artistry from foundation to flawless finished looks.",
     "features": ["Makeup fundamentals", "Party & occasion looks", "Product knowledge"], "price": None},
    {"name": "Advanced Aesthetics and Makeup Artistry Course",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.40_PM.jpg",
     "description": "Combine advanced aesthetics with makeup artistry for a complete professional skill set.",
     "features": ["Aesthetics techniques", "Advanced makeup artistry", "Bridal & HD makeup"], "price": None},
    {"name": "Advanced Aesthetics and Permanent Makeup Course",
     "image": "https://res.cloudinary.com/rimbtl5i/image/upload/v1787753602/WhatsApp_Image_2026-08-26_at_6.34.10_PM.jpg",
     "description": "Specialise in advanced aesthetics and permanent makeup procedures.",
     "features": ["Permanent makeup", "Advanced aesthetics", "Hands-on practice"], "price": None},
]


async def seed():
    # indexes
    await db.users.create_index("email", unique=True)
    await db.payments.create_index("merchant_order_id", unique=True)
    await db.course_access.create_index([("user_id", 1), ("item_type", 1), ("item_id", 1)], unique=True)

    # admin
    admin_email = os.environ["ADMIN_EMAIL"].lower()
    admin_password = os.environ["ADMIN_PASSWORD"]
    existing = await db.users.find_one({"email": admin_email})
    if not existing:
        await db.users.insert_one({
            "name": "Ayesha Admin", "email": admin_email,
            "password_hash": hash_password(admin_password), "role": "admin",
            "created_at": now_utc().isoformat(),
        })
    elif not verify_password(admin_password, existing["password_hash"]) or existing.get("role") != "admin":
        await db.users.update_one({"email": admin_email},
                                  {"$set": {"password_hash": hash_password(admin_password), "role": "admin"}})

    # config
    if not await db.config.find_one({"id": "site"}):
        await db.config.insert_one({
            "id": "site", "hero_video_url": "", "google_maps_link": "",
            "google_review_link": "", "salon_meet_link": "", "fitness_meet_link": "",
            "phonepe_merchant_id": "", "phonepe_client_id": "", "phonepe_client_secret": "",
        })

    # v2 reseed: exactly four academy courses with correct pricing & covers
    cfg = await db.config.find_one({"id": "site"}) or {}
    if not cfg.get("seed_v3"):
        await db.courses.delete_many({})
        await db.masterclasses.delete_many({})
        for c in COURSES_V2:
            doc = {"id": str(uuid.uuid4()), "type": "academy", "active": True,
                   "meet_link": "https://meet.google.com/pda-coxo-peq", "lectures": [
                       {"id": str(uuid.uuid4()), "title": "Module 1 – Introduction", "description": "Course overview and foundations.", "video_url": ""},
                       {"id": str(uuid.uuid4()), "title": "Module 2 – Core Techniques", "description": "Hands-on core techniques.", "video_url": ""},
                       {"id": str(uuid.uuid4()), "title": "Module 3 – Advanced Practice", "description": "Advanced practical training.", "video_url": ""},
                       {"id": str(uuid.uuid4()), "title": "Module 4 – Professional Finishing", "description": "Client handling and finishing.", "video_url": ""},
                   ], **c}
            await db.courses.insert_one(doc)
        await db.config.update_one({"id": "site"}, {"$set": {
            "seed_v3": True,
            "salon_meet_link": "https://meet.google.com/pda-coxo-peq",
            "fitness_meet_link": "https://meet.google.com/kqp-fuar-ebz",
            "hero_video_url": LANDING_VIDEO,
        }})

    # write test credentials
    try:
        creds = f"""# Test Credentials

## Admin (role: admin)
- Email: {admin_email}
- Password: {admin_password}

## Student test account
- Register a new account via /login (Register tab) or use one created during testing.
- Role: student

## Auth endpoints
- POST /api/auth/register
- POST /api/auth/login
- POST /api/auth/logout
- GET  /api/auth/me

## Notes
- Payment runs in MOCK mode (APP_MODE=mock). Course access granted for 30 days on mock-complete.
"""
        Path("/app/memory/test_credentials.md").write_text(creds)
    except Exception as e:
        logger.warning(f"Could not write test_credentials: {e}")


@app.on_event("startup")
async def startup():
    await seed()


@api.get("/")
async def root():
    return {"message": "Ayesha Salon & Academy API"}


app.include_router(api)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origin_regex=".*",
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
