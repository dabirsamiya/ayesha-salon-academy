# Auth Testing Playbook — Aisha Salon & Academy

## Admin
- Email: dabirlubna@gmail.com
- Password: AishaAdmin@2026

## Endpoints
- POST /api/auth/register  {name,email,phone,password}
- POST /api/auth/login  {email,password}
- POST /api/auth/logout
- GET  /api/auth/me

Auth uses JWT via httpOnly cookie AND Bearer token (returned in login/register body as `token`).
Frontend stores token in localStorage `aisha_token` and sends Authorization header.

## Curl
curl -c cookies.txt -X POST $URL/api/auth/login -H "Content-Type: application/json" -d '{"email":"dabirlubna@gmail.com","password":"AishaAdmin@2026"}'
curl -b cookies.txt $URL/api/auth/me

## Payment (mock mode)
- POST /api/payments/create {item_type:"course",item_id}
- POST /api/payments/{order}/mock-complete
- GET  /api/payments/{order}
Access granted 30 days on mock-complete.
